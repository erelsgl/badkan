This is a sample exercise.
The assignment is:

> Write a C++ unit named "reverse" (files reverse.h and reverse.cpp)
with a single function named "reverse"
that accepts a string and returns it in reverse.

A sample solution can be found at:
https://github.com/ereltest/reverse.git
