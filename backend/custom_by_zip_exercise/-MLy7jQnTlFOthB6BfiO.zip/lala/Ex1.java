

public class Ex1 {
	public static void main(String[] args) {
		
		int x=0,y=0;
		if(args.length > 0) {
			x = Integer.parseInt(args[0]);
			y= Integer.parseInt(args[1]);
		}
		else {
			x = MyConsole.readInt("enter first number");
			y = MyConsole.readInt("enter seconde number");
		}
		
		
		
		int mpcd =1;
		
		   for(int i=2; i<= (Math.max(x,y)); i++) {
		       while(x%i==0 && y%i==0) {
		           mpcd=i;
		           x = x/mpcd;
		           y = y/mpcd;
		       }
		   }
		    System.out.println("Max prime common divider : "+mpcd);
		    
	      if (mpcd == 1 || mpcd==0) {
			   System.out.println("there isn't solution because 0 or 1 are not prime");
		   
		} 
	}

}