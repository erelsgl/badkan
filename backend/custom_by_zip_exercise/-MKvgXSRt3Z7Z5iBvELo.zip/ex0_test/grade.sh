#!/bin/bash

javac Test.java
java Test
