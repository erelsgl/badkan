
#include <iostream>
using std::ostream;

namespace ariel {

class Tree {
private:
	int mySize;
public:
	
	Tree() {
		mySize = 0;
	}
	
	int size() { 
		return mySize; 
	}
	
	Tree& insert(int i) {
		++mySize;
		// TODO: find the correct place for i and return it
		return *this; 
	}
	
	Tree& remove(int i) {
		--mySize;
		// TODO: find i and remove it
		return *this; 
	}
	
	int parent(int i) {
		// TODO: find and return the parent of i
		return 0;
	}
	
	int left(int i) {
		// TODO: find and return the left child of i
		return 0;
	}
	
	int right(int i) {
		// TODO: find and return the right child of i
		return 0;
	}
	
	int root() {
		return 0;
	}
	
	static int treeCount() {
		// TODO: return the total number of trees in the system
		return 0;
	}
	void print() const {}
	bool contains(int) const { return false; }
};

} // end namespace ariel
